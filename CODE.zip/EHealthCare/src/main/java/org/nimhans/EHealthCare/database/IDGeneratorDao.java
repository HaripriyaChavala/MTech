package org.nimhans.EHealthCare.database;

public interface IDGeneratorDao 
{
	public String getCurrentRoot();

}
