package org.nimhans.EHealthCare;
/* FINISHED - an asset is FINISHED if all its children are finished
 * 
 * ENTERED - when it enters a station
 * 
 * EXITED - at least one child gets created for it
 */
public enum StatusType {
	ENTERED,EXITED,FINISHED

}
