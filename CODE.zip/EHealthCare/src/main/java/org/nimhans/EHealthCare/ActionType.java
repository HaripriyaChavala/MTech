package org.nimhans.EHealthCare;

public enum ActionType {
	ENTER,EXIT

}
