package org.nimhans.EHealthCare.model.derived;

import org.nimhans.EHealthCare.model.Flow;

public class NimhansFlow extends Flow{
	
	public NimhansFlow()
	{
		super();
	}
	public NimhansFlow(String flow)
	{
		super(flow);
	}
}
