package org.nimhans.EHealthCare;

/* SPECIAL_GROSSING,SPECIAL_STAINING,SPECIAL_SECTIONING - related to root
 * 
 * If root is not normal all the children created will be of SPECIAL type
 * 
 * 
 */

public enum SpecialType {
	NORMAL, SPECIAL_GROSSING, SPECIAL_SECTIONING, SPECIAL_STAINING, SPECIAL

}
