package org.nimhans.EHealthCare.database;
import org.nimhans.EHealthCare.model.Patient;
public interface RequestDao 
{
	public String getPatientID(String requestId);

}
