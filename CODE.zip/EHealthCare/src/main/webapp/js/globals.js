var app=angular.module('GlobalURL',[]);
app.value('serverURL','http://localhost:8080/EHealthCare/webapi');